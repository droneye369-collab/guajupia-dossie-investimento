# Guajupiá — Dossiê de Transição e Investimento

Aplicação web de página única que junta a **apresentação do projeto** (12 seções navegáveis)
com um **modelo de investimento e valuation** que recalcula em tempo real.

Português BR, sem build, sem dependências. Um arquivo HTML resolve.

---

## Como rodar

```bash
cd guajupia-app
python3 -m http.server 8000
# abra http://localhost:8000
```

Ou simplesmente abra `index.html` com dois cliques. O app funciona nos dois modos:

| Modo | O que acontece |
|---|---|
| Servido (`http.server`) | Lê `dados/custos.json` e `dados/cronograma.json` do disco. Editar esses arquivos muda o app. |
| Arquivo solto (`file://`) | Usa a cópia embutida dos mesmos dados. Nada quebra. |

---

## O que dá para fazer

**Navegar.** Índice lateral com as 11 seções, setas ← → do teclado, links de anterior/próxima no pé.

**Editar tudo.** Todo campo com sublinhado tracejado é editável. Alterar qualquer número
recalcula na hora o capital, o payback, o gráfico de caixa, a folha e os três métodos de valuation.

- Seção 05 — acompanhar as ações recorrentes do dia a dia
- Seção 07 — adicionar e excluir itens de custo, preencher os orçamentos em aberto
- Seção 08 — salários, número de registrados, encargos, manutenção, eventuais
- Seção 10 — cenário de folha, reserva de giro, receita, mês da primeira venda, rampa, horizonte
- Seção 11 — fator de conservação, valor da terra, múltiplo, taxa de desconto, crescimento

**Salvar e retomar.** `Exportar dados` baixa um JSON com o estado inteiro. `Importar dados`
carrega de volta. A seção 06 também exporta um `custos.json` no formato original do pacote,
para substituir o arquivo em `dados/`.

**Imprimir.** `Imprimir / PDF` abre todas as seções em páginas separadas, sem menus nem botões.

**Gerar texto com IA.** Botão no topo. Ver abaixo.

---

## O modelo financeiro

Modelo de caixa mês a mês. Não considera imposto, depreciação nem o valor da terra
(a menos que você informe na seção 10).

```
custo mensal   = nº registrados × salário bruto × (1 + encargos) + eventuais + manutenção
receita mês m  = 0, se m < mês da primeira venda
                 receita cheia × min(1, (m − início + 1) / rampa), caso contrário
acumulado[0]   = − capital inicial
acumulado[m]   = acumulado[m−1] + receita[m] − custo mensal
```

- **Capital inicial** = soma dos custos orçados + reserva de giro (ou o valor que você digitar)
- **Retorno do capital** = primeiro mês em que o acumulado cruza o zero
- **Caixa necessário** = ponto mais baixo do acumulado, em módulo. É o dinheiro que precisa
  existir de verdade, não só o capital de implantação. Se for maior que o capital previsto,
  o card fica vermelho e mostra quanto falta.

### Valuation — três métodos

| Método | Como calcula | Serve para |
|---|---|---|
| Custo de reposição | custos orçados × fator de conservação + terra | piso da negociação |
| Múltiplo de resultado | resultado anual em regime pleno × múltiplo + terra | referência de mercado |
| Fluxo descontado | VPL de N anos com taxa de desconto e crescimento + terra | valor de longo prazo |

A faixa entre o menor e o maior é a informação útil. O número do meio é só a média dos três.

---

## Integração com IA

O botão **Gerar texto com IA** abre um painel que escreve a narrativa de qualquer seção
usando os números que você acabou de editar. Dois provedores:

**Google Gemini** — `gemini-2.5-flash` ou `gemini-2.5-pro`

```
POST https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={CHAVE}
{"contents":[{"parts":[{"text": "..."}]}]}
```

**DeepSeek via Nous** — `deepseek/deepseek-v4-pro` ou `deepseek/deepseek-v4-flash`

```
POST https://inference-api.nousresearch.com/v1/chat/completions
Authorization: Bearer {CHAVE}
{"model":"...","messages":[{"role":"user","content":"..."}]}
```

O prompt é montado automaticamente com o contexto do projeto e os seus números atuais,
e fica editável antes de enviar. O resultado pode ser inserido direto na seção
como um bloco marcado "Narrativa gerada por IA".

### Chaves de API

A chave é digitada no painel, vive só na memória da aba e some ao fechar a página.
Não vai para `localStorage`, não é enviada a lugar nenhum além do provedor escolhido,
e não existe nenhuma chave escrita no código.

Para uso em servidor próprio, use `.env.example` como base e faça a chamada pelo backend,
com o front batendo num endpoint seu. É o único jeito de a chave não trafegar pelo navegador.

### Limitações conhecidas

- **Geração de imagem:** `gemini-2.5-flash-image` está com cota zero no free tier desta conta
  (erro 429). Os placeholders `.img-ph` foram mantidos, como pede o briefing. DeepSeek não gera imagem.
- **Pré-visualizações e sandboxes** bloqueiam requisições externas. Se a chamada falhar com
  "Failed to fetch", baixe o arquivo e rode com `python3 -m http.server`.
- **CORS:** o Gemini aceita chamada direta do navegador. O endpoint da Nous pode exigir proxy;
  se der erro de CORS, a saída é o backend.

Existe também o botão **Rascunho local**, que monta um texto coerente para cada seção
a partir dos seus próprios números, sem chave e sem rede. Útil para ensaiar a apresentação offline.

---

## Correções feitas no protótipo original

1. **Carregamento de dados quebrado.** O protótipo usava
   `<script src="dados/custos.json" type="application/json">` e depois lia `.textContent`.
   Script externo não popula `textContent`, então `JSON.parse` recebia string vazia e o app
   não subia quando servido. Agora os dados ficam embutidos em blocos JSON inline e o app
   tenta buscar `dados/*.json` por `fetch`, sobrescrevendo o embutido quando encontra.

2. **Folha sem encargos.** O cálculo usava R$ 7.000 e R$ 2.350 fixos, sem os 42–45% de encargos
   e sem a manutenção mensal. Um registrado a R$ 2.350 de bruto custa cerca de R$ 3.372.
   O modelo agora aplica encargos sobre o bruto e soma manutenção e eventuais.

3. **Payback ignorava o tempo de maturação.** A fórmula era `capital / (receita − folha)`,
   assumindo receita desde o primeiro mês. Mas a estufa leva cerca de três meses até a primeira
   colheita vendável, e o PNAE demora mais. Agora a receita começa no mês que você definir
   e sobe em rampa, o que muda o payback em vários meses e revela a necessidade real de caixa.

4. **Variáveis globais implícitas.** `calc()` acessava `cap`, `rec`, `meses`, `cen` e `res`
   pelo id do elemento, sem declarar nada. Funciona por acidente do navegador e quebra
   em modo estrito. Substituído por estado explícito com ligação declarativa de campos.

---

## Estrutura

```
guajupia-app/
├── index.html      app inteiro: HTML, CSS e JS num arquivo só
├── dados/
│   ├── custos.json       custos diretos, folha, canais, produção
│   └── cronograma.json   fases M1–M6 e marcos de validação
├── .env.example    modelo para as chaves, se for usar backend
└── README.md
```

---

## Notas de conteúdo

- `CONTEXTO.md` cita um `dados/guajupia.md` (o master plan do Obsidian) que **não veio no zip**.
  As seções de propósito, equipe, estruturas e riscos foram escritas a partir do que existe em
  `custos.json`, `cronograma.json` e nas notas do protótipo. Se o master plan aparecer,
  vale revisar esses textos.
- Os valores de receita e reserva de giro são **premissas de partida**, não dados do plano.
  O pacote original não trazia projeção de receita. Ajuste na seção 09 assim que houver
  a primeira venda registrada.
- Brete, chalés Hobbit e o desenho da área de 1,5 ha seguem sem orçamento. Enquanto isso,
  o capital inicial exibido é piso, não número final.
